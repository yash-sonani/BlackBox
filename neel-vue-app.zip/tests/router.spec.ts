import { test, expect } from '@playwright/test'

test.describe('Router', () => {
  test('should redirect root to dashboard', async ({ page }) => {
    await page.goto('/')
    await expect(page).toHaveURL('/dashboard')
  })

  test('should access dashboard route', async ({ page }) => {
    await page.goto('/dashboard')
    await expect(page).toHaveURL('/dashboard')
  })
})
