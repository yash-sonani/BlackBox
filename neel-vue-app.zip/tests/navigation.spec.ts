import { test, expect } from '@playwright/test'

test.describe('Navigation', () => {
  test('should load dashboard page by default', async ({ page }) => {
    await page.goto('/')
    await expect(page).toHaveTitle(/FinTech Dasboard/)
    await expect(page).toHaveURL('/dashboard')
  })
})
