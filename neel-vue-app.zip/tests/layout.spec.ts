import { test, expect } from '@playwright/test'

test.describe('App Layout', () => {
  test('should not display savings plan page on dashboard load', async ({ page }) => {
    await page.goto('/')
    const savingsPlanPage = page.locator('.savings-plan-page')
    await expect(savingsPlanPage).not.toBeVisible()
  })

  test('should navigate to savings plan page when button is clicked', async ({ page }) => {
    await page.goto('/')
    const savingsPlanButton = page.locator('text=EC2')
    await savingsPlanButton.click()
    const savingsPlanPage = page.locator('.savings-plan-page')
    await expect(savingsPlanPage).toBeVisible()
  })
})
