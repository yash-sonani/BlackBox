<template>
  <div class="dashboard">
    <DashboardHeader />
    <div class="dashboard-content">
      <DashboardSidebar />
      <main class="main-content">
        <DashboardStats />
        <div class="dashboard-grid">
          <div class="main-section">
            <PortfolioChart />
          </div>
          <div class="side-section">
            <CoverageAnalysis />
          </div>
        </div>
        <div class="full-width-section">
          <UtilizationHealth />
        </div>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import DashboardHeader from '@/components/dashboard/DashboardHeader.vue'
import DashboardSidebar from '@/components/dashboard/DashboardSidebar.vue'
import DashboardStats from '@/components/dashboard/DashboardStats.vue'
import PortfolioChart from '@/components/dashboard/PortfolioChart.vue'
import CoverageAnalysis from '@/components/dashboard/CoverageAnalysis.vue'
import UtilizationHealth from '@/components/dashboard/UtilizationHealth.vue'
</script>

<style scoped>
.dashboard {
  min-height: 100vh;
  background-color: #f8fafc;
}

.dashboard-content {
  display: flex;
}

.main-content {
  flex: 1;
  padding: 2rem;
  margin-left: 250px;
}

.dashboard-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  margin-top: 2rem;
}

.main-section {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.side-section {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.full-width-section {
  margin-top: 2rem;
}

.additional-widgets {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

@media (max-width: 1024px) {
  .main-content {
    margin-left: 0;
    padding: 1rem;
  }

  .dashboard-grid {
    grid-template-columns: 1fr;
  }

  .additional-widgets {
    flex-direction: row;
    gap: 1rem;
  }
}

@media (max-width: 768px) {
  .additional-widgets {
    flex-direction: column;
  }
}
</style>
