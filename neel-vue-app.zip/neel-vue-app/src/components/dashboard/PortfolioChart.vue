<template>
  <div class="data-table-section">
    <div class="table-header">
      <div class="header-content">
        <h3>Ec2 Savings Plans Inventory</h3>
        <p class="subtitle">$222.00/hr total commitment</p>
      </div>
      <div class="table-controls">
        <div class="search-box">
          <svg class="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
            stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <input type="text" placeholder="Search by ID, account, type, region, or instance family..."
            class="search-input" />
        </div>
      </div>
    </div>

    <div class="table-wrapper">
      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>SAVING PLAN ID</th>
              <th>STATUS</th>
              <th>TYPE</th>
              <th>INSTANCE FAMILY</th>
              <th>REGION</th>
              <th>COMMITMENT</th>
              <th>SAVING %</th>
              <th>START DATE</th>
              <th>END DATE</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in tableData" :key="item.id">
              <td class="service-cell">
                <a href="#" class="plan-id-link">{{ item.service }}</a>
              </td>
              <td class="status-cell">
                <span :class="['status-badge', item.status.toLowerCase()]">{{ item.status }}</span>
              </td>
              <td class="usage-cell">
                <span class="usage-value">{{ item.type }}</span>
              </td>
              <td class="instance-family-cell">
                <span class="instance-family-value">{{ item.instanceFamily }}</span>
              </td>
              <td class="target-cell">
                <span class="target-value">{{ item.region }}</span>
              </td>
              <td class="coverage-cell">
                <span class="commitment-value">${{ formatNumber(item.commitment) }}</span>
              </td>
              <td class="saving-cell">
                <span class="saving-value">{{ item.savingPercent }}%</span>
              </td>
              <td class="start-date-cell">
                <span class="start-date-value">{{ item.startDate }}</span>
              </td>
              <td class="end-date-cell">
                <span class="end-date-value">{{ item.endDate }}</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface TableItem {
  id: number
  service: string
  type: string
  currentUsage: number
  target: number
  coverage: number
  status: string
  instanceFamily: string
  region: string
  commitment: number
  savingPercent: number
  startDate: string
  endDate: string
}

const tableData = ref<TableItem[]>([
  {
    id: 1,
    service: '0398d3ea-7c85-4d64-81c3',
    type: 'EC2 Instance',
    currentUsage: 15420.5,
    target: 18000.0,
    coverage: 85.7,
    status: 'Active',
    instanceFamily: 'm5.large',
    region: 'us-east-1',
    commitment: 1250.0,
    savingPercent: 30,
    startDate: '2024-01-15',
    endDate: '2025-01-15',
  },
  {
    id: 2,
    service: '1a2b3c4d-5e6f-7g8h-9i0j',
    type: 'EC2 Instance',
    currentUsage: 8250.75,
    target: 10000.0,
    coverage: 82.5,
    status: 'Active',
    instanceFamily: 'c5.xlarge',
    region: 'us-west-2',
    commitment: 890.5,
    savingPercent: 25,
    startDate: '2024-03-10',
    endDate: '2025-03-10',
  },
  {
    id: 3,
    service: '2b3c4d5e-6f7g-8h9i-0j1k',
    type: 'EC2 Instance',
    currentUsage: 2340.25,
    target: 5000.0,
    coverage: 46.8,
    status: 'Expired',
    instanceFamily: 'r5.2xlarge',
    region: 'eu-west-1',
    commitment: 2150.75,
    savingPercent: 35,
    startDate: '2023-06-20',
    endDate: '2024-06-20',
  },
  {
    id: 4,
    service: '3c4d5e6f-7g8h-9i0j-1k2l',
    type: 'EC2 Instance',
    currentUsage: 1250.0,
    target: 2000.0,
    coverage: 62.5,
    status: 'Active',
    instanceFamily: 't3.medium',
    region: 'ap-southeast-1',
    commitment: 675.25,
    savingPercent: 20,
    startDate: '2024-02-28',
    endDate: '2025-02-28',
  },
  {
    id: 5,
    service: '4d5e6f7g-8h9i-0j1k-2l3m',
    type: 'EC2 Instance',
    currentUsage: 890.5,
    target: 1500.0,
    coverage: 59.4,
    status: 'Expired',
    instanceFamily: 'i3.large',
    region: 'ca-central-1',
    commitment: 1450.0,
    savingPercent: 28,
    startDate: '2023-08-12',
    endDate: '2024-08-12',
  },
])

const formatNumber = (num: number): string => {
  return num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
</script>

<style scoped>
.data-table-section {
  background: white;
  border: 1px solid #e5e5e5;
  overflow: hidden;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
}

.header-content {
  display: flex;
  flex-direction: column;
}

.table-header h3 {
  margin: 0;
  color: #171717;
  font-size: 1.125rem;
  font-weight: 600 !important;
}

.subtitle {
  margin: 0;
  color: #737373;
  font-size: 0.875rem;
  font-weight: 400;
}

.table-controls {
  display: flex;
  gap: 1rem;
  align-items: center;
  margin-right: 4rem;
}

.search-box {
  position: relative;
  width: 600px;
}

.search-icon {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #737373;
  pointer-events: none;
}

.search-input {
  padding: 1rem 1rem 1rem 2.5rem;
  border: 1px solid #e5e5e5;
  border-radius: 6px;
  font-size: 0.875rem;
  width: 100%;
}

.search-input:focus {
  outline: none;
  border-color: #3b82f6;
}

.table-wrapper {
  overflow-x: scroll;
  overflow-y: scroll;
  border: 1px solid #e5e5e5;
  max-height: 400px;
  margin-bottom: 5px;
}

.table-container {
  width: 100%;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}

.data-table th {
  background: #fafafa;
  padding: 1rem;
  text-align: left;
  font-weight: 600;
  color: #171717;
  font-size: 0.875rem;
  border-bottom: 1px solid #e5e5e5;
}

.data-table td {
  padding: 1rem;
  border-bottom: 1px solid #e5e5e5;
  font-size: 0.875rem;
  color: #171717;
}

.data-table tr:hover {
  background: #fafafa;
  color: #171717;
}

.plan-id-link {
  color: #3b82f6;
  text-decoration: none;
  font-weight: 600;
  cursor: pointer;
}

.plan-id-link:hover {
  text-decoration: underline;
}

.instance-family-value {
  font-weight: 500;
  color: #171717;
}

.status-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
}

.status-badge.active {
  background: #dcfce7;
  color: #16a34a;
}

.status-badge.expired {
  background: #fef2f2;
  color: #dc2626;
}

@media (max-width: 768px) {
  .table-header {
    flex-direction: column;
    gap: 1rem;
    align-items: flex-start;
  }

  .table-controls {
    width: 100%;
    justify-content: space-between;
  }

  .search-box {
    width: 100%;
  }

  .data-table {
    font-size: 0.75rem;
  }

  .data-table th,
  .data-table td {
    padding: 0.75rem 0.5rem;
  }

  .coverage-bar {
    width: 40px;
  }
}
</style>
