<template>
  <div class="coverage-analysis">
    <div class="section-header">
      <h3>Coverage Analysis</h3>
      <span class="total-savings">32% of your EC2 usage lacks SP coverage</span>
      <div class="coverage-section">
        <span class="coverage-percentage">82%</span>
      </div>

      <div class="progress-header">
        <span class="progress-title">Current Coverage</span>
        <div class="progress-info">
          <span class="progress-status">Good</span>
          <span class="progress-target">Target: 85%+</span>
        </div>
      </div>
      <div class="progress-bar">
        <div class="progress-fill" style="width: 82%"></div>
      </div>
    </div>

    <div class="recommendations-list">
      <div
        v-for="recommendation in recommendations"
        :key="recommendation.id"
        class="recommendation-item"
      >
        <div class="recommendation-content">
          <div class="recommendation-header">
            <div>
              <h4 class="recommendation-title">{{ recommendation.title }}</h4>
              <div class="spend-amount">$23,420<span class="spend-period"> / month</span></div>
              <div class="coverage-warning">Without Savings Plan coverage</div>
              <div class="potential-savings">Potential Savings</div>
              <div class="saving-amount">$7,000<span class="spend-period"> / month</span></div>
              <div class="coverage-description">With optimal coverage (30% avg rate)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface Recommendation {
  id: number
  title: string
  description: string
  savings: number
  priority: 'High' | 'Medium' | 'Low'
  effort: string
  timeline: string
}

const recommendations = ref<Recommendation[]>([
  {
    id: 1,
    title: 'On-Demand Spend',
    description:
      'Optimize instance types based on actual usage patterns to reduce costs by up to 30%.',
    savings: 1250.0,
    priority: 'High',
    effort: 'Low',
    timeline: '1-2 weeks',
  },
])

const formatNumber = (num: number): string => {
  return num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
</script>

<style scoped>
.coverage-analysis {
  background: white;
  border-radius: 8px;
  border: 1px solid #e5e5e5;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  min-height: 505px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #e5e5e5;
  background: #fafafa;
}

.section-header h3 {
  margin: 0;
  color: #171717;
  font-size: 1.125rem;
  font-weight: 600 !important;
}

.section-header {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 1.5rem;
  border-bottom: 1px solid #e5e5e5;
  background: white;
}

.total-savings {
  font-size: 0.875rem;
  color: #737373;
}

.total-savings strong {
  color: #16a34a;
  font-weight: 600;
}

.coverage-section {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.coverage-percentage {
  font-size: 2rem;
  font-weight: bold;
  color: #171717;
  text-align: left;
}

.progress-section {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  overflow: hidden;
}

.progress-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.progress-info {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 0.25rem;
  text-align: right;
}

.progress-status {
  font-size: 0.875rem;
  color: #16a34a;
  font-weight: 600;
}

.progress-target {
  font-size: 0.75rem;
  color: #737373;
}

.progress-title {
  font-size: 0.875rem;
  color: #737373;
}

.progress-bar {
  width: 100%;
  height: 16px;
  background-color: #e5e5e5;
  border-radius: 8px;
  overflow: hidden;
  margin: 0;
}

.progress-fill {
  height: 100%;
  background-color: #650360;
  transition: width 0.3s ease;
}

.recommendations-list {
  display: flex;
  flex-direction: column;
  flex: 1;
}

.recommendation-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  border-bottom: 1px solid #e5e5e5;
  transition: background-color 0.2s;
}

.recommendation-item:last-child {
  border-bottom: none;
}

.recommendation-item:hover {
  background: #fafafa;
}

.recommendation-icon {
  margin-top: 0.25rem;
}

.priority-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

.priority-indicator.high {
  background: #dc2626;
}

.priority-indicator.medium {
  background: #d97706;
}

.priority-indicator.low {
  background: #16a34a;
}

.recommendation-content {
  flex: 1;
}

.recommendation-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.5rem;
}

.coverage-description {
  font-size: 0.875rem;
  color: #16a34a;
  margin-top: 0.25rem;
}

.potential-savings {
  font-size: 1rem;
  color: #171717;
  margin-top: 0.25rem;
}

.coverage-warning {
  font-size: 0.875rem;
  color: #dc2626;
  margin-top: 0.25rem;
}

.spend-amount {
  font-size: 1.25rem;
  font-weight: bold;
  color: #171717;
  margin-top: 0.25rem;
}

.saving-amount {
  font-size: 1.25rem;
  font-weight: bold;
  color: #16a34a;
  margin-top: 0.25rem;
}

.spend-period {
  font-weight: normal;
  color: #737373;
  font-size: 1rem;
}

.recommendation-title {
  margin: 0;
  font-size: 1rem;
  font-weight: 400;
  color: #171717;
}

.priority-badge {
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
}

.priority-badge.high {
  background: #fef2f2;
  color: #dc2626;
}

.priority-badge.medium {
  background: #fef3c7;
  color: #d97706;
}

.priority-badge.low {
  background: #dcfce7;
  color: #16a34a;
}

.recommendation-description {
  margin: 0 0 1rem 0;
  font-size: 0.875rem;
  color: #737373;
  line-height: 1.5;
}

.recommendation-metrics {
  display: flex;
  gap: 2rem;
}

.metric {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.metric-label {
  font-size: 0.75rem;
  color: #737373;
  text-transform: uppercase;
  font-weight: 500;
}

.metric-value {
  font-size: 0.875rem;
  font-weight: 600;
  color: #171717;
}

.metric-value.savings {
  color: #16a34a;
}

.recommendation-actions {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: 0.25rem;
}

.action-btn {
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid transparent;
}

.action-btn.primary {
  background: #3b82f6;
  color: white;
}

.action-btn.primary:hover {
  background: #2563eb;
}

.action-btn.secondary {
  background: white;
  color: #737373;
  border-color: #e5e5e5;
}

.action-btn.secondary:hover {
  background: #f5f5f5;
  color: #171717;
}

@media (max-width: 768px) {
  .section-header {
    flex-direction: column;
    gap: 1rem;
    align-items: flex-start;
  }

  .header-actions {
    width: 100%;
    justify-content: space-between;
  }

  .recommendation-item {
    flex-direction: column;
    gap: 1rem;
  }

  .recommendation-header {
    flex-direction: column;
    gap: 0.5rem;
    align-items: flex-start;
  }

  .recommendation-metrics {
    flex-direction: column;
    gap: 1rem;
  }

  .recommendation-actions {
    flex-direction: row;
    width: 100%;
  }

  .action-btn {
    flex: 1;
  }
}
</style>
