<template>
  <div class="savings-plan-page">
    <div class="page-header">
      <div class="header-content">
        <h2>EC2 Savings Plans Inventory</h2>
        <p class="commitment-info">$222.00/hr total commitment</p>
      </div>
      <div class="header-actions">
        <div class="search-container">
          <svg
            class="search-icon"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Search by ID, account, type, region, or instance family..."
            class="search-input"
          />
        </div>
      </div>
    </div>

    <div class="datatable-container">
      <div class="table-wrapper">
        <table class="savings-table">
          <thead>
            <tr>
              <th>Offering ID</th>
              <th>Savings Plan ID</th>
              <th>Description</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Status</th>
              <th>Instance Family</th>
              <th>Payment Option</th>
              <th>Product Types</th>
              <th>Commitment</th>
              <th>Returnable Until</th>
              <th>Recurring Payment</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="plan in filteredPlans" :key="plan.id">
              <td>{{ plan.offeringId }}</td>
              <td>
                <a href="#" class="plan-link">{{ plan.savingsPlanId }}</a>
              </td>
              <td>{{ plan.description }}</td>
              <td>{{ plan.start }}</td>
              <td>{{ plan.end }}</td>
              <td>
                <span :class="['status', plan.state.toLowerCase()]">{{ plan.state }}</span>
              </td>
              <td>{{ plan.ec2InstanceFamily }}</td>
              <td>{{ plan.paymentOption }}</td>
              <td>{{ plan.productTypes }}</td>
              <td>${{ formatCurrency(plan.commitment) }}</td>
              <td>{{ plan.returnableUntil }}</td>
              <td>${{ formatCurrency(plan.recurringPaymentAmount) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

interface SavingsPlan {
  id: number
  offeringId: string
  savingsPlanId: string
  description: string
  start: string
  end: string
  state: string
  ec2InstanceFamily: string
  paymentOption: string
  productTypes: string
  commitment: number
  returnableUntil: string
  recurringPaymentAmount: number
}

const searchQuery = ref('')

const savingsPlans = ref<SavingsPlan[]>([
  {
    id: 1,
    offeringId: 'sp-offer-12345',
    savingsPlanId: 'sp-0398d3ea7c854d64',
    description: 'EC2 Instance Savings Plan - 1 Year',
    start: '2024-01-15',
    end: '2025-01-15',
    state: 'Active',
    ec2InstanceFamily: 'm5',
    paymentOption: 'All Upfront',
    productTypes: 'EC2',
    commitment: 1250.0,
    returnableUntil: '2024-01-22',
    recurringPaymentAmount: 104.17,
  },
  {
    id: 2,
    offeringId: 'sp-offer-67890',
    savingsPlanId: 'sp-1a2b3c4d5e6f7g8h',
    description: 'Compute Savings Plan - 3 Year',
    start: '2024-03-10',
    end: '2027-03-10',
    state: 'Active',
    ec2InstanceFamily: 'c5',
    paymentOption: 'Partial Upfront',
    productTypes: 'EC2, Fargate',
    commitment: 890.5,
    returnableUntil: '2024-03-17',
    recurringPaymentAmount: 37.1,
  },
  {
    id: 3,
    offeringId: 'sp-offer-11111',
    savingsPlanId: 'sp-2b3c4d5e6f7g8h9i',
    description: 'EC2 Instance Savings Plan - 1 Year',
    start: '2023-06-20',
    end: '2024-06-20',
    state: 'Expired',
    ec2InstanceFamily: 'r5',
    paymentOption: 'No Upfront',
    productTypes: 'EC2',
    commitment: 2150.75,
    returnableUntil: '2023-06-27',
    recurringPaymentAmount: 179.23,
  },
])

const filteredPlans = computed(() => {
  if (!searchQuery.value) return savingsPlans.value

  const query = searchQuery.value.toLowerCase()
  return savingsPlans.value.filter(
    (plan) =>
      plan.offeringId.toLowerCase().includes(query) ||
      plan.savingsPlanId.toLowerCase().includes(query) ||
      plan.description.toLowerCase().includes(query) ||
      plan.ec2InstanceFamily.toLowerCase().includes(query) ||
      plan.state.toLowerCase().includes(query),
  )
})

const formatCurrency = (amount: number): string => {
  return amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
</script>

<style scoped>
.savings-plan-page {
  background: #ffffff;
  border: 1px solid #bbbbbb;
  box-shadow:
    0px 1px 3px rgba(0, 0, 0, 0.1),
    0px 1px 2px -1px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 17.5px 21px;
  border-bottom: 1px solid rgba(229, 229, 229, 0.6);
  background: #ffffff;
}

.header-content h2 {
  margin: 0 0 1.75px 0;
  font-weight: 600;
  font-size: 15.75px;
  line-height: 24px;
  color: #171717;
}

.commitment-info {
  margin: 0;
  font-weight: 400;
  font-size: 12.25px;
  line-height: 18px;
  color: #737373;
}

.header-actions {
  display: flex;
  align-items: center;
}

.search-container {
  position: relative;
  width: 461px;
  height: 41px;
}

.search-icon {
  position: absolute;
  left: 12.25px;
  top: 11.5px;
  width: 17.5px;
  height: 17.5px;
  color: #a3a3a3;
  pointer-events: none;
}

.search-input {
  width: 100%;
  height: 100%;
  padding: 10.5px 14px 10.5px 38.5px;
  background: #fafafa;
  border: 1px solid #e5e5e5;
  border-radius: 12px;
  font-weight: 400;
  font-size: 12.25px;
  line-height: 15px;
  color: rgba(23, 23, 23, 0.5);
  box-sizing: border-box;
}

.search-input:focus {
  outline: none;
  border-color: #3b82f6;
}

.datatable-container {
  height: 340px;
  overflow: hidden;
  position: relative;
}

.table-wrapper {
  width: 100%;
  height: 100%;
  overflow-x: auto;
  overflow-y: auto;
}

.savings-table {
  border-collapse: collapse;
  width: 200%;
  table-layout: fixed;
}

.savings-table th {
  background: #fafafa;
  padding: 17.5px 14px;
  text-align: left;
  font-weight: 600;
  font-size: 10.5px;
  line-height: 14px;
  letter-spacing: 0.525px;
  text-transform: uppercase;
  color: #525252;
  border-bottom: 1px solid rgba(229, 229, 229, 0.6);
  position: sticky;
  top: 0;
  z-index: 10;
  height: 49.5px;
  box-sizing: border-box;
}

.savings-table td {
  padding: 17.5px 14px;
  border-bottom: 1px solid #f5f5f5;
  font-size: 12.25px;
  line-height: 18px;
  color: #171717;
  white-space: nowrap;
  height: 73px;
  box-sizing: border-box;
  vertical-align: middle;
}

.savings-table tr:hover {
  background: #f9fafb;
}

.plan-link {
  font-weight: 400;
  font-size: 12.25px;
  line-height: 18px;
  color: #155dfc;
  text-decoration: none;
}

.plan-link:hover {
  text-decoration: underline;
}

.status {
  display: inline-block;
  padding: 6.25px 11.5px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 12.25px;
  line-height: 18px;
  text-transform: capitalize;
}

.status.active {
  background: #f0fdf4;
  border: 1px solid #b9f8cf;
  color: #008236;
}

.status.expired {
  background: #fed3d3;
  border: 1px solid #d63440;
  color: #d63440;
}

/* Column widths - equal distribution across 200% width */
.savings-table th,
.savings-table td {
  width: 8.33%;
  min-width: 8.33%;
}

/* Scrollbar styling */
.table-wrapper::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-wrapper::-webkit-scrollbar-track {
  background: #f1f5f9;
}

.table-wrapper::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 4px;
}

.table-wrapper::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

@media (max-width: 1024px) {
  .page-header {
    flex-direction: column;
    gap: 1rem;
    align-items: stretch;
  }

  .search-container {
    width: 100%;
  }

  .datatable-container {
    height: 300px;
  }
}

@media (max-width: 768px) {
  .page-header {
    padding: 1rem;
  }

  .savings-table th,
  .savings-table td {
    padding: 12px 8px;
    font-size: 11px;
  }

  .datatable-container {
    height: 250px;
  }
}
</style>
