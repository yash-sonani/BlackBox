<template>
  <div class="utilization-health">
    <div class="section-header">
      <h3>Utilization Health</h3>
    </div>
    <div class="utilization-content">
      <div class="left-section">
        <div class="utilization-label">Overall Utilization</div>
        <div class="utilization-percentage">84%</div>
      </div>
      <div class="right-section">
        <div class="accounts-label">Total accounts</div>
        <div class="accounts-number">28</div>
      </div>
    </div>
    <div class="table-container">
      <table class="utilization-table">
        <thead>
          <tr>
            <th>ENVIRONMENT</th>
            <th>UTILIZATION</th>
            <th>ACCOUNTS</th>
            <th>SPEND</th>
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Production</td>
            <td>92%</td>
            <td>15</td>
            <td>$12,450</td>
            <td><span class="status-badge excellent">Excellent</span></td>
          </tr>
          <tr>
            <td>Development</td>
            <td>78%</td>
            <td>8</td>
            <td>$5,230</td>
            <td><span class="status-badge good">Good</span></td>
          </tr>
          <tr>
            <td>Testing</td>
            <td>65%</td>
            <td>5</td>
            <td>$2,890</td>
            <td><span class="status-badge fair">Fair</span></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="table-divider"></div>
    <div class="trend-section">
      <div class="trend-left">
        <span class="trend-arrow">↗</span>
        <span class="trend-text"
          >Overall trend: <span class="trend-percentage">+21%</span> this month</span
        >
      </div>
      <div class="trend-right">
        <span class="total-spend-text"
          >Total spend: <span class="total-spend-amount">$20,570</span></span
        >
      </div>
    </div>
    <div class="optimization-section">
      <div class="optimization-content">
        <div class="optimization-left">
          <div class="optimization-icon">⚙️</div>
          <div class="optimization-text">
            <h4 class="optimization-title">Optimization Opportunity Detected</h4>
            <p class="optimization-description">
              We identified potential savings of $5,458/month by adjusting your commitment levels
              based on usage patterns.
            </p>
            <a href="#" class="optimization-link">View recommendations →</a>
          </div>
        </div>
        <div class="optimization-right">
          <div class="estimated-savings">Estimated savings</div>
          <div class="savings-amount">$5,458</div>
          <div class="savings-period">/month</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// Component logic can be added here
</script>

<style scoped>
.utilization-health {
  background: white;
  border-radius: 8px;
  border: 1px solid #e5e5e5;
  overflow: hidden;
}

.section-header {
  padding: 1.5rem;
  border-bottom: 1px solid #e5e5e5;
}

.section-header h3 {
  margin: 0;
  color: #171717;
  font-size: 1.125rem;
  font-weight: 600;
  text-align: left;
}

.utilization-content {
  display: flex;
  justify-content: space-between;
  padding: 1.5rem;
}

.left-section {
  text-align: left;
}

.right-section {
  text-align: right;
}

.utilization-label,
.accounts-label {
  font-size: 0.875rem;
  color: #737373;
  margin-bottom: 0.5rem;
}

.utilization-percentage,
.accounts-number {
  font-size: 2rem;
  font-weight: bold;
  color: #171717;
}

.table-container {
  overflow-x: auto;
  margin: 0 1.5rem 1.5rem 1.5rem;
  border: 1px solid #e5e5e5;
  border-radius: 8px;
}

.utilization-table {
  width: 100%;
  border-collapse: collapse;
}

.utilization-table th {
  background: #fafafa;
  padding: 1rem;
  text-align: left;
  font-weight: 600;
  color: #171717;
  font-size: 0.875rem;
  border-bottom: 1px solid #e5e5e5;
}

.utilization-table td {
  padding: 1rem;
  border-bottom: 1px solid #e5e5e5;
  font-size: 0.875rem;
  color: #171717;
}

.utilization-table tr:hover {
  background: #fafafa;
}

.status-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
}

.status-badge.excellent {
  background: #dcfce7;
  color: #16a34a;
}

.status-badge.good {
  background: #dbeafe;
  color: #2563eb;
}

.status-badge.fair {
  background: #fef3c7;
  color: #d97706;
}

.table-divider {
  height: 1px;
  background-color: #e5e5e5;
  margin: 0 1.5rem;
}

.trend-section {
  padding: 1rem 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.trend-left {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.trend-right {
  display: flex;
  align-items: center;
}

.trend-arrow {
  color: #16a34a;
  font-size: 1.25rem;
  font-weight: bold;
}

.trend-text {
  font-size: 0.875rem;
  color: #171717;
}

.trend-percentage {
  color: #16a34a;
  font-weight: 600;
}

.total-spend-text {
  font-size: 0.875rem;
  color: #171717;
}

.total-spend-amount {
  color: #171717;
  font-weight: 600;
}

.optimization-section {
  margin: 1.5rem;
  background: #f0f9ff;
  border: 1px solid #e0f2fe;
  border-radius: 8px;
  padding: 1.5rem;
}

.optimization-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.optimization-left {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  flex: 1;
}

.optimization-icon {
  font-size: 1.5rem;
}

.optimization-text {
  flex: 1;
}

.optimization-title {
  margin: 0 0 0.5rem 0;
  font-size: 1rem;
  font-weight: 600;
  color: #171717;
}

.optimization-description {
  margin: 0 0 0.5rem 0;
  font-size: 0.875rem;
  color: #737373;
  line-height: 1.4;
}

.optimization-link {
  color: #2563eb;
  text-decoration: none;
  font-size: 0.875rem;
  font-weight: 500;
}

.optimization-link:hover {
  text-decoration: underline;
}

.optimization-right {
  text-align: right;
}

.estimated-savings {
  font-size: 0.75rem;
  color: #737373;
  margin-bottom: 0.25rem;
}

.savings-amount {
  font-size: 1.5rem;
  font-weight: bold;
  color: #171717;
}

.savings-period {
  font-size: 0.875rem;
  color: #737373;
}
</style>
