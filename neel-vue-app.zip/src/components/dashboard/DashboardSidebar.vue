<template>
  <aside class="dashboard-sidebar">
    <nav class="sidebar-nav">
      <ul class="nav-list">
        <li class="nav-item">
          <RouterLink to="/" class="nav-link" @click="handleSavingPlanClick">
            💰 Saving Plan
          </RouterLink>
        </li>
      </ul>
    </nav>
  </aside>
</template>

<script setup lang="ts">
import { RouterLink } from 'vue-router'
import { useInventoryState } from '@/composables/useInventoryState'

const { setShowInventory } = useInventoryState()

const handleSavingPlanClick = () => {
  setShowInventory(false)
}
</script>

<style scoped>
.dashboard-sidebar {
  position: fixed;
  left: 0;
  top: 70px;
  width: 250px;
  height: calc(100vh - 70px);
  background: white;
  border-right: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
  z-index: 999;
}

.sidebar-nav {
  flex: 1;
  padding: 1rem 0;
}

.nav-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.nav-item {
  margin-bottom: 0.25rem;
}

.nav-link {
  display: flex;
  align-items: center;
  padding: 0.75rem 1.5rem;
  color: #64748b;
  text-decoration: none;
  transition: all 0.2s;
  font-size: 0.875rem;
}

.nav-link:hover {
  background: #f1f5f9;
  color: #1e40af;
}

.nav-link.active,
.nav-link.router-link-exact-active {
  background: #650360;
  color: white;
  border-right: 3px solid #650360;
}

.sidebar-footer {
  padding: 1rem;
}

.upgrade-card {
  background: linear-gradient(135deg, #1e40af, #3b82f6);
  color: white;
  padding: 1rem;
  border-radius: 8px;
  text-align: center;
}

.upgrade-card h4 {
  margin: 0 0 0.5rem 0;
  font-size: 0.875rem;
}

.upgrade-card p {
  margin: 0 0 1rem 0;
  font-size: 0.75rem;
  opacity: 0.9;
}

.upgrade-btn {
  background: white;
  color: #1e40af;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  width: 100%;
}

@media (max-width: 1024px) {
  .dashboard-sidebar {
    transform: translateX(-100%);
    transition: transform 0.3s;
  }

  .dashboard-sidebar.open {
    transform: translateX(0);
  }
}
</style>
