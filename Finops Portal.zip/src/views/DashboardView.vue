<template>
  <div class="dashboard">
    <DashboardHeader />
    <div class="dashboard-content">
      <DashboardSidebar />
      <main class="main-content">
        <DashboardStats />
        <div class="dashboard-grid">
          <div class="main-section">
            <Inventory v-if="showInventory" />
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import DashboardHeader from '@/components/SavingPlan/DashboardHeader.vue'
import DashboardSidebar from '@/components/SavingPlan/DashboardSidebar.vue'
import DashboardStats from '@/components/SavingPlan/DashboardStats.vue'
import Inventory from '@/components/SavingPlan/Inventory.vue'
import { useInventoryState } from '@/composables/useInventoryState'

const { showInventory } = useInventoryState()
</script>

<style scoped>
.dashboard {
  min-height: 100vh;
  background-color: #f5f4f4;
}

.dashboard-content {
  display: flex;
}

.main-content {
  flex: 1;
  padding: 2rem;
  margin-left: 250px;
  width: calc(100vw - 250px - 4rem);
  max-width: calc(100vw - 250px - 4rem);
  box-sizing: border-box;
  overflow: hidden;
}

.dashboard-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 2rem;
  margin-top: 2rem;
}

.main-section {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.side-section {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.full-width-section {
  margin-top: 2rem;
}

.additional-widgets {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

@media (max-width: 1024px) {
  .main-content {
    margin-left: 0;
    padding: 1rem;
    width: calc(100vw - 2rem);
    max-width: calc(100vw - 2rem);
  }

  .dashboard-grid {
    grid-template-columns: 1fr;
  }

  .additional-widgets {
    flex-direction: row;
    gap: 1rem;
  }
}

@media (max-width: 768px) {
  .additional-widgets {
    flex-direction: column;
  }
}
</style>
