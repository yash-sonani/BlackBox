<template>
  <header class="dashboard-header">
    <div class="header-left">
      <img src="@/assets/ally-logo.svg" alt="Ally Logo" class="logo" />
      <h1 class="dashboard-title">Cloud Finops Enterprise Dashboard</h1>
    </div>

    <!-- <div class="header-right">
      <button class="logout-btn" @click="handleLogout">Logout</button>
    </div> -->
  </header>
</template>

<script setup lang="ts">
// const handleLogout = () => {
//   // Add logout logic here
//   console.log('Logout clicked')
// }
</script>

<style scoped>
.dashboard-header {
  background: #650360;
  border-bottom: 1px solid #e5e5e5;
  padding: 0 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  height: 70px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.logo {
  height: 40px;
  width: auto;
}

.dashboard-title {
  font-size: 1.0rem;
  font-weight: 600;
  color: white;
  margin: 0;
}

.header-right {
  flex: 0 0 auto;
}

.logout-btn {
  padding: 0.5rem 1.5rem;
  background: #dc2626;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.logout-btn:hover {
  background: #b91c1c;
}

@media (max-width: 768px) {
  .dashboard-header {
    padding: 0 1rem;
  }

  .dashboard-title {
    font-size: 1.2rem;
  }
}
</style>
