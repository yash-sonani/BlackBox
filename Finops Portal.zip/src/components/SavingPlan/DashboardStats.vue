<template>
  <div class="dashboard-stats">
    <!-- Cloud Provider Toggle -->
    <div class="cloud-provider-toggle">
      <button class="provider-tab" :class="{ active: activeProvider === 'aws' }" @click="setActiveProvider('aws')">
        <img src="@/assets/aws.png" alt="AWS" class="provider-icon" />
        AWS
        <span v-if="activeProvider === 'aws'" class="active-tag">Active</span>
      </button>
      <button class="provider-tab" :class="{ active: activeProvider === 'azure' }" @click="setActiveProvider('azure')">
        <img src="@/assets/azure.png" alt="Azure" class="provider-icon" />
        Azure
        <span v-if="activeProvider === 'azure'" class="active-tag">Active</span>
      </button>
    </div>

    <!-- Overview Section -->
    <h2>Overview</h2>
    <div class="stats-grid">
      <div class="stat-box" :class="{ selected: selectedBox === 'ec2' }" @click="selectBox('ec2')">
        <div class="box-header">
          <h3>EC2</h3>
          <button class="help-btn">?</button>
        </div>
        <p>$12,450</p>
      </div>
      <div class="stat-box" :class="{ selected: selectedBox === 'compute' }" @click="selectBox('compute')">
        <div class="box-header">
          <h3>Compute</h3>
          <button class="help-btn">?</button>
        </div>
        <p>$8,320</p>
      </div>
      <div class="stat-box" :class="{ selected: selectedBox === 'sagemaker' }" @click="selectBox('sagemaker')">
        <div class="box-header">
          <h3>SageMaker</h3>
          <button class="help-btn">?</button>
        </div>
        <p>$5,680</p>
      </div>
      <div class="stat-box" :class="{ selected: selectedBox === 'database' }" @click="selectBox('database')">
        <div class="box-header">
          <h3>Database</h3>
          <button class="help-btn">?</button>
        </div>
        <p>$9,150</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useInventoryState } from '@/composables/useInventoryState'

// Active provider state
const activeProvider = ref<'aws' | 'azure'>('aws')
const selectedBox = ref<string | null>(null)
const { setShowInventory } = useInventoryState()

const setActiveProvider = (provider: 'aws' | 'azure') => {
  activeProvider.value = provider
}

const selectBox = (box: string) => {
  selectedBox.value = selectedBox.value === box ? null : box
  setShowInventory(box === 'ec2',)
}

const totalBalance = ref(125430.5)
const portfolioValue = ref(82.0) 
const monthlySpending = ref(5458.0) 
const savingsGoal = ref(50000.0)

const formatNumber = (num: number): string => {
  return num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
</script>

<style scoped>
.dashboard-stats {
  margin-top: 70px;
  padding-top: 1rem;
}

.cloud-provider-toggle {
  display: flex;
  background: white;
  border: 1px solid #e5e5e5;
  border-radius: 6px;
  overflow: hidden;
  margin-bottom: 2rem;
  width: fit-content;
}

.provider-tab {
  padding: 0.25rem 0.5rem;
  border: none;
  background: white;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  position: relative;
}

.provider-tab.active {
  color: white;
}

.provider-tab.active:first-child {
  background: #eb6600;
}

.provider-tab.active:last-child {
  background: #0078d4;
}

.provider-tab:hover:not(.active) {
  background: #f5f5f5;
}

.provider-tab.active .provider-icon {
  filter: brightness(0) invert(1);
}

.provider-icon {
  width: 30px;
  height: 30px;
}

.active-tag {
  background: rgba(255, 255, 255, 0.2);
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 600;
}

h2 {
  margin: 0 0 1.5rem 0;
  font-size: 1.5rem;
  color: #171717;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1.5rem;
}

.stat-box {
  background: #f8fafc;
  border: 1px solid #e5e5e5;
  border-radius: 6px;
  padding: 1.5rem;
  cursor: pointer;
  transition: all 0.2s;
}

.stat-box.selected {
  background: white;
  border-color: #650360;
}

.box-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.stat-box h3 {
  margin: 0;
  font-size: 1rem;
  color: #171717;
  text-align: left;
}

.help-btn {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 1px solid #d1d5db;
  background: white;
  color: #6b7280;
  font-size: 0.75rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.help-btn:hover {
  background: #f3f4f6;
  border-color: #9ca3af;
}

.stat-box p {
  margin: 0;
  font-size: 1.25rem;
  font-weight: 600;
  color: #171717;
  text-align: left;
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 480px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .section-header {
    flex-direction: column;
    gap: 1rem;
    align-items: flex-start;
  }

  .coverage-info {
    flex-direction: column;
    gap: 1rem;
    align-items: flex-start;
  }

  .stats-grid {
    grid-template-columns: 1fr;
  }

  .stat-card {
    padding: 1rem;
    border-right: none;
    border-bottom: 1px solid #e5e5e5;
  }

  .stat-card:last-child {
    border-bottom: none;
  }

  .stat-value {
    font-size: 1.25rem;
  }
}
</style>
