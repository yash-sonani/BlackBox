import { ref } from 'vue'

const showInventory = ref(false)

export function useInventoryState() {
  const setShowInventory = (show: boolean) => {
    showInventory.value = show
  }

  return {
    showInventory,
    setShowInventory,
  }
}
